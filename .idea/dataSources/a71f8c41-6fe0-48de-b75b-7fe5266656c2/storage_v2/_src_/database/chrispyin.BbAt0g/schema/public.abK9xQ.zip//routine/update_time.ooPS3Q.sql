create function update_time() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.modified = now();
    RETURN NEW; 
END;
$$;

alter function update_time() owner to postgres;

